# Driver patches — how to apply

| patch | what it does | in the shipped image? |
|---|---|---|
| `900-cr6608-lab-txpower-38dbm.patch` | raises the SKU **request** ceiling to 38 dBm, adds the `cr6608_rf_38dbm` parameter and the `CR6608-TXTRACE` logging | **yes** — the shipped `mt7915e.ko` already carries this |
| `901-cr6608-eeprom-power-38dbm.patch` | raises the **EEPROM-derived** bound to 38 dBm in the RAM copy, and stops that bound from clamping the value actually programmed | **no** — needs a rebuild; inert until you build it |

`900` is a **reconstruction** from binary analysis of the shipped module, not the
original author's file — read the header inside the patch before using it.

`901` is the one that addresses the 26 dBm. Patch 900 rewrites the SKU array *after*
`mt76_get_rate_power_limits()` returns, but the value that ends up in
`phy->mt76->txpower_cur` — the figure iwinfo and LuCI display — is the function's
**return value**, which is still clamped to the EEPROM rate-power table. 901 closes
that gap. Its header explains what it costs; read it before enabling the parameter.

Apply order matters: 901's `mt7915/mcu.c` hunk sits inside the block that 900 adds, so
900 must be applied first.

**Neither patch writes the Factory/EEPROM MTD partition.** 901 edits only the copy of
the EEPROM held in kernel memory, so a reboot or `cr6608_eeprom_38dbm=0` undoes it.

## Where it goes

OpenWrt builds mt76 from the `mt76` package. Patches live in:

```
openwrt/package/kernel/mt76/patches/
```

So:

```bash
mkdir -p openwrt/package/kernel/mt76/patches
cp patches/900-cr6608-lab-txpower-38dbm.patch openwrt/package/kernel/mt76/patches/
cp patches/901-cr6608-eeprom-power-38dbm.patch openwrt/package/kernel/mt76/patches/
```

Then build normally. The patch applies to paths relative to the mt76 source root
(`mt7915/mcu.c`, `mt7915/init.c`, `mt7915/mt7915.h`).

## If it fails to apply

Function bodies around the hunks change between mt76 revisions, so a `.rej` is
likely on a tree far from the one this was written against. Fix it by hand:

```bash
cd openwrt
make package/kernel/mt76/{clean,prepare} V=s QUILT=1
cd build_dir/target-*/linux-*/mt76-*/
quilt push -a                 # stops at the failing patch
# edit the file(s) the patch touches, then:
quilt refresh
cp patches/900-cr6608-lab-txpower-38dbm.patch \
   ../../../../package/kernel/mt76/patches/
```

The three edits are small and independent — if only one hunk fails you can drop it
and keep the rest:

| hunk | file | what it does | required for 38 dBm? |
|---|---|---|---|
| 1 | `mt7915/mcu.c` | module parameter + SKU ceiling + trace | **yes** |
| 2 | `mt7915/init.c` | load-time banner | no (cosmetic) |
| 3 | `mt7915/mt7915.h` | accessor prototype | only if hunk 2 is kept |

Hunk 1 alone gives you the working 38 dBm request ceiling.

## Verify it worked

After building, the module must expose the parameter and the strings:

```bash
strings bin/targets/ramips/mt7621/*/mt7915e.ko \
  | grep -E 'cr6608_rf_38dbm|cr6608_eeprom_38dbm|CR6608-LAB-38|CR6608-EEPROM'
```

Compare against the reference module in `../prebuilt/mt7915e.ko`:

```bash
strings ../prebuilt/mt7915e.ko | grep -cE 'cr6608_rf_38dbm'   # expect 2
```

On the running device:

```bash
cat /sys/module/mt7915e/parameters/cr6608_rf_38dbm       # expect Y
cat /sys/module/mt7915e/parameters/cr6608_eeprom_38dbm   # expect Y (patch 901)
logread | grep CR6608
```

With 901 built and enabled, `logread` gains two lines that say whether it did anything:

```
CR6608-EEPROM RAM override (Factory MTD untouched): target_2g .. delta_5g ..
CR6608-TXTRACE stage=mt7915-eeprom-bypass band=0 eeprom_clamped_half_dbm=52 restored_half_dbm=70
```

`52` is 26.0 dBm — the clamp. `restored_half_dbm` is what gets programmed instead.
Then re-read the applied figure and decide whether it was worth it:

```bash
iw dev wlan0 info | grep txpower
cr6608-txpower-verify
```

If throughput drops or clients at range get *worse*, the amplifier is compressing —
set `cr6608_eeprom_38dbm=0` in `/etc/modules.d/mt7915e` and reboot.

## Skipping the patch entirely

If you are rebuilding against the **same kernel (6.12.94)** and only changed
`files/`, you do not need the patch at all — copy the already-patched module into
the overlay:

```bash
mkdir -p files/lib/modules/6.12.94
cp prebuilt/mt7915e.ko files/lib/modules/6.12.94/
```

A different kernel version rejects it (`vermagic` mismatch); then the patch is the
only route.

## What the patch does not include

The original module also exposes a debugfs snapshot at
`/sys/kernel/debug/ieee80211/<phy>/mt76/cr6608_txpower_state`. That is pure
observability and is not reproduced here — it needs a struct member in `mt7915.h`
and a `debugfs_create_file` entry. `cr6608-txpower-collect` handles the file being
absent; it simply records fewer fields. `driver-patch-NOTES.md` lists the full field
set if you want to add it back.
