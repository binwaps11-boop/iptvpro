# mt7915 “CR6608-LAB-38” driver patch — reconstruction notes

The patch **source is not in this package** (this was reconstructed from a built
image). These notes describe exactly what the compiled `mt7915e.ko` in the shipped
firmware does, so the patch can be recreated if the original `.patch` is lost.

Target: `package/kernel/mac80211` (mt76 driver), file `mt7915/` —
specifically the paths that build the TX-power SKU tables and the init/rate hooks.

---

## 1. Module parameter

Extracted from the built module:

```
parmtype=cr6608_rf_38dbm:bool
```

A `bool` module parameter named `cr6608_rf_38dbm`, enabled at load time by
`files/etc/modules.d/mt7915e`:

```
mt7915e cr6608_rf_38dbm=1
```

Guard every behaviour below behind this parameter so the stock path is unchanged
when it is 0.

## 2. Load-time banner

```
CR6608-LAB-38 observability enabled (38 dBm is a request only; EEPROM, regulatory,
SAR, rate backoff and thermal limits retained; Factory remains read-only)
```

This is the patch’s own statement of scope, and it is accurate: the patch raises the
**requested** SKU ceiling and adds tracing. It does **not** bypass regulatory limits,
does not touch SAR, does not disable thermal/rate backoff, and does not write Factory.

## 3. SKU request ceiling

The earlier 24.10 build of this patch carried the ceiling in a single string:

```
SKU cck/ofdm=76 mcs=72 ru=68 half-dBm; request ceiling only, actual RF hardware/PA limited
```

Units are **half-dBm**, so:

| group | half-dBm | dBm |
|---|---|---|
| cck / ofdm | 76 | 38.0 |
| mcs | 72 | 36.0 |
| ru (HE resource units) | 68 | 34.0 |

Applied inside `mt7915_mcu_set_txpower_sku` when the parameter is on.

> Note: `mcs` and `ru` are intentionally *below* 38. Raising them to 76 makes every
> group read 38.0, but changes nothing measurable — the PA saturates far below even
> the current 34–36 dBm ceiling, so those groups are not the binding constraint.

## 4. State snapshot + copy helper

Symbols present in the built module:

```
cr6608_txpower_state
mt7915_cr6608_txpower_state_copy
```

A per-phy snapshot struct capturing each stage of the power chain, plus a copy
helper used by the debug/trace surface.

## 5. TXTRACE observability

Four `printk` sites, one per stage. These are what make `logread | grep TXTRACE`
useful — each prints every limiter in the chain so you can see which one binds:

```
CR6608-TXTRACE stage=mt7915-init   band= channel= freq= chains= chain0_half_dbm= chain1_half_dbm=
                                   eeprom_max_half_dbm= delta_half_dbm= rate_max_half_dbm=
                                   path_delta_half_dbm= target_dbm= reg_dbm= max_dbm= sku= path_sku=

CR6608-TXTRACE stage=mt7915-eeprom band= channel= freq= chainmask= chain0_half_dbm= chain1_half_dbm=
                                   eeprom_max_half_dbm= rate_input_half_dbm= effective_half_dbm= sku=

CR6608-TXTRACE stage=mt7915-rate   band= channel= freq= width= mac80211_dbm= sar_half_dbm=
                                   path_delta_half_dbm= bound_half_dbm= rate_limit_half_dbm=
                                   effective_half_dbm= sku= path_sku= [sku_cck0= sku_ofdm0= sku_mcs0= sku_ru0=]
```

Plus MCU command results:

```
CR6608-LAB-38 band=%u MCU rate-SKU command completed
CR6608-LAB-38 band=%u MCU rate-SKU rejected: %d
CR6608-LAB-38 band=%u MCU path-SKU command completed
CR6608-LAB-38 band=%u MCU path-SKU rejected: %d
CR6608-LAB-38 band=%u path-SKU not configured
```

The “rejected” lines matter: if the MCU refuses the SKU command, the requested
ceiling never reaches the firmware — that shows up here and nowhere else.

## 6. Device-tree marker

```
mediatek,cr6608-lab-txpower-38dbm
```

An optional DT property the patch looks for, alongside the board compatible
`xiaomi,mi-router-cr6608`.

---

## Reading the trace on a live unit

```sh
logread | grep TXTRACE | tail -20
```

Follow the chain left to right; the smallest value wins:

```
eeprom_max_half_dbm  →  EEPROM/Factory calibration ceiling
reg_dbm              →  regulatory domain
sar_half_dbm         →  SAR table
rate_limit_half_dbm  →  per-rate backoff
bound_half_dbm       →  final bound handed to the MCU
effective_half_dbm   →  what was actually programmed
```

If `effective_half_dbm` is well below `target_dbm`, the stage whose value matches
`effective` is the one that is binding — that is the thing to address, not the UCI
`txpower` value.
