#!/bin/bash
# CR6608 Smart AP — build helper.
#
#   ./build.sh deps     install Ubuntu build prerequisites
#   ./build.sh init     clone OpenWrt 25.12.5 + feeds into ./openwrt
#   ./build.sh overlay  copy files/ into the build root
#   ./build.sh config   open menuconfig (pick MT7621 / CR6608 profile)
#   ./build.sh build    full build
#   ./build.sh repack   repack the image only (after editing files/)
#
# Run them in that order the first time; afterwards `overlay` + `repack` is enough.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
OWRT="${OWRT:-$HERE/openwrt}"
TAG="${TAG:-v25.12.5}"

need_tree() {
  [ -d "$OWRT" ] || { echo "no OpenWrt tree at $OWRT — run: $0 init"; exit 1; }
}

case "${1:-}" in
deps)
  sudo apt update
  sudo apt install -y build-essential clang flex bison g++ gawk gcc-multilib \
    g++-multilib gettext git libncurses-dev libssl-dev python3-setuptools \
    rsync swig unzip zlib1g-dev file wget
  ;;

init)
  [ -d "$OWRT" ] || git clone https://git.openwrt.org/openwrt/openwrt.git "$OWRT"
  cd "$OWRT"
  git fetch --tags
  git checkout "$TAG"
  ./scripts/feeds update -a
  ./scripts/feeds install -a
  echo
  echo "OpenWrt $TAG ready at $OWRT"
  echo "If you have the mt7915 38 dBm patch, drop it into"
  echo "  $OWRT/package/kernel/mac80211/patches/  BEFORE building."
  echo "See driver-patch-NOTES.md."
  ;;

overlay)
  need_tree
  rm -rf "$OWRT/files"
  cp -a "$HERE/files" "$OWRT/files"
  echo "overlay installed: $(find "$OWRT/files" \( -type f -o -type l \) | wc -l) entries"
  ;;

config)
  need_tree
  cd "$OWRT"
  echo "Target System  : MediaTek Ralink MIPS"
  echo "Subtarget      : MT7621"
  echo "Target Profile : Xiaomi Mi Router CR6608"
  echo "Packages       : see packages-installed.txt"
  make menuconfig
  ;;

build)
  need_tree
  cd "$OWRT"
  make -j"$(nproc)"
  echo
  ls -la bin/targets/ramips/mt7621/*cr6608*sysupgrade.bin 2>/dev/null || \
    echo "no image found — rerun with: make -j1 V=s"
  ;;

repack)
  need_tree
  cd "$OWRT"
  make target/install -j"$(nproc)"
  ls -la bin/targets/ramips/mt7621/*cr6608*sysupgrade.bin 2>/dev/null || true
  ;;

*)
  sed -n '2,12p' "$0"
  exit 1
  ;;
esac
