# CR6608 Smart AP — build source package (v22)

Everything needed to rebuild this firmware from an OpenWrt source tree on Ubuntu,
**including the driver patch.**

Built and verified against: **OpenWrt 25.12.5** (`r33051-f5dae5ece4`), kernel
**6.12.94**, target `ramips/mt7621`, device `xiaomi,mi-router-cr6608`.

---

## Contents

| Path | What it is |
|---|---|
| `files/` | rootfs overlay (102 entries) — drop into the OpenWrt build root as `files/` |
| `patches/900-cr6608-lab-txpower-38dbm.patch` | **the 38 dBm driver patch** (reconstructed) |
| `patches/README.md` | how to apply it, fix a reject, and verify the result |
| `packages-installed.txt` | the 172 packages present in the built image |
| `driver-patch-NOTES.md` | full reconstruction notes for the driver patch |
| `prebuilt/mt7915e.ko` | the **patched** Wi-Fi driver, as built (kernel 6.12.94) |
| `prebuilt/kernel-uImage-6.12.94.bin` | the kernel image, as built |
| `build.sh` | `deps / init / patch / overlay / config / build / verify / repack` |

### What `files/` contains

- `usr/sbin`, `usr/bin`, `usr/libexec` — all `cr6608-*` and `smartap-*` helpers
- `etc/init.d` + `etc/rc.d` — services and their boot symlinks
- `etc/uci-defaults` — first-boot configuration
- `etc/hotplug.d/ieee80211`, `etc/sysctl.d`
- `etc/config/*` — wireless, network, dhcp, firewall, system, smartap, cr6608quick,
  dropbear, uhttpd, luci, rpcd
- `etc/modules.d/mt7915e` — **the 38 dBm switch**: `mt7915e cr6608_rf_38dbm=1`
- `www/` — the Smart AP dashboard: `index.html`, `dashboard.js`, every `cgi-bin`
  handler (`dashctl`, `dashapi2`, `dashlogin`, `dashlogout`, `dashluci`, …)
- `usr/share/rpcd/acl.d`, `usr/share/luci/menu.d` — ACL + menu for the custom app

---

## Build on Ubuntu

```bash
# 1. prerequisites
./build.sh deps

# 2. clone OpenWrt 25.12.5 + feeds into ./openwrt
./build.sh init

# 3. install the 38 dBm driver patch (into package/kernel/mt76/patches/)
./build.sh patch

# 4. install the overlay
./build.sh overlay

# 5. configure:  MediaTek Ralink MIPS → MT7621 → Xiaomi Mi Router CR6608
#    then select the packages from packages-installed.txt
./build.sh config

# 6. build
./build.sh build

# 7. confirm the module really carries the patch
./build.sh verify
```

If the patch will not apply to your tree (function context drifts between mt76
revisions), see `patches/README.md` — or skip it entirely and reuse the
already-patched module:

```bash
./build.sh prebuilt-module && ./build.sh overlay && ./build.sh repack
```
That only works while the kernel stays 6.12.94.

Output:
```
openwrt/bin/targets/ramips/mt7621/openwrt-*-xiaomi_mi-router-cr6608-squashfs-sysupgrade.bin
```

### After editing only `files/`

```bash
./build.sh overlay && ./build.sh repack
```
Repacks the image without recompiling everything — seconds instead of hours.

---

## What is NOT here

- **The original author's patch file.** `patches/900-cr6608-lab-txpower-38dbm.patch`
  is a reconstruction from binary analysis of the shipped module — it reproduces the
  observable behaviour, but the context lines may need adjusting for your mt76
  revision. `patches/README.md` covers fixing a reject and verifying the result.
- **The OpenWrt source, the toolchain and `.config`** — the build steps generate them.

### Using the prebuilt

If you rebuild against the *same* kernel (6.12.94) and only changed `files/`, you can
drop `prebuilt/mt7915e.ko` into your overlay at
`files/lib/modules/6.12.94/mt7915e.ko` to keep the 38 dBm behaviour without the
patch. This only works while the kernel version matches exactly — a different kernel
rejects the module (`vermagic` mismatch), and then the patch is the only route.

---

## Power chain in this build

`38 dBm` is asserted at every software layer:

1. `etc/config/wireless` — `txpower '38'` on both radios, `antenna_gain '0'`,
   `he_mu_beamformer` + `he_mu_beamformee` on both (full MU-MIMO)
2. `etc/modules.d/mt7915e` — `cr6608_rf_38dbm=1` enables the raised SKU ceiling
3. the driver patch — SKU ceiling + TXTRACE + debugfs snapshot
4. `usr/libexec/cr6608-txpower-lib` — upper bound and default both 38
5. `usr/sbin/cr6608-txpower-{collect,channel-table,step-test}` — evidence tools

The driver states its own scope:

> `38 dBm is a request only; EEPROM, regulatory, SAR, rate backoff and thermal limits
> retained; Factory remains read-only`

So the stack *requests* 38 dBm; the PA, regulatory domain, SAR and thermal limits
still bound what is actually radiated. `cr6608-eeprom-power` in this image is a
read-only inspector (`status`, `backup`) and never writes MTD.

Check the real numbers on a running unit:
```sh
logread | grep TXTRACE
cat /sys/kernel/debug/ieee80211/phy0/mt76/cr6608_txpower_state
cr6608-txpower-collect --out /tmp/evidence
```

---

## What changed in v22 (vs the stock RC image)

- **Firmware upload inside the Smart AP page** — Actions tab gains an upload card;
  goes through `cgi-io` to `/tmp/firmware.bin`, validated with `sysupgrade --test`
  before anything is written, then flashed (`-n` when keep-settings is off). New
  `flash_firmware` action in `dashctl`.
- **LuCI logout returns to the Smart AP page** (`action_logout` → `/`).
- **12 audited fixes** in `dashctl` / `dashapi2` / `dashboard.js` — the dead `nohup`
  port-restore timer, PID truncation in `kill_process`, `opkg`→`apk`, JSON control
  characters, firewall port truncation, the zone guard, MAC validation, SSID pipe
  shifting, `safe_host` option injection, radio distance truncation, load-average
  divisor, unused isolation note.
- **`he_mu_beamformee`** added to both radios (MU-MIMO was only half declared).
- Identity card shows customer name / phone / device explicitly.
