# CR6608 Smart AP — build source package (v22)

Everything needed to rebuild this firmware from an OpenWrt source tree on Ubuntu,
**except the mt7915 driver patch source** — see “What is NOT here”.

Built and verified against: **OpenWrt 25.12.5** (`r33051-f5dae5ece4`), kernel
**6.12.94**, target `ramips/mt7621`, device `xiaomi,mi-router-cr6608`.

---

## Contents

| Path | What it is |
|---|---|
| `files/` | rootfs overlay (102 entries) — drop into the OpenWrt build root as `files/` |
| `packages-installed.txt` | the 172 packages present in the built image |
| `driver-patch-NOTES.md` | full reconstruction notes for the 38 dBm driver patch |
| `prebuilt/mt7915e.ko` | the **patched** Wi-Fi driver, as built (kernel 6.12.94) |
| `prebuilt/kernel-uImage-6.12.94.bin` | the kernel image, as built |
| `build.sh` | `deps / init / overlay / config / build / repack` helper |

### What `files/` contains

- `usr/sbin`, `usr/bin`, `usr/libexec` — all `cr6608-*` and `smartap-*` helpers
- `etc/init.d` + `etc/rc.d` — services and their boot symlinks
- `etc/uci-defaults` — first-boot configuration
- `etc/hotplug.d/ieee80211`, `etc/sysctl.d`
- `etc/config/*` — wireless, network, dhcp, firewall, system, smartap, cr6608quick,
  dropbear, uhttpd, luci, rpcd
- `etc/modules.d/mt7915e` — **the 38 dBm switch**: `mt7915e cr6608_rf_38dbm=1`
- `www/` — the Smart AP dashboard: `index.html`, `dashboard.js`, every `cgi-bin`
  handler (`dashctl`, `dashapi2`, `dashlogin`, `dashlogout`, `dashluci`, …)
- `usr/share/rpcd/acl.d`, `usr/share/luci/menu.d` — ACL + menu for the custom app

---

## Build on Ubuntu

```bash
# 1. prerequisites
./build.sh deps

# 2. clone OpenWrt 25.12.5 + feeds into ./openwrt
./build.sh init

# 3. (optional but needed for 38 dBm) copy your mt7915 patch into
#    openwrt/package/kernel/mac80211/patches/   — see driver-patch-NOTES.md

# 4. install the overlay
./build.sh overlay

# 5. configure:  MediaTek Ralink MIPS → MT7621 → Xiaomi Mi Router CR6608
#    then select the packages from packages-installed.txt
./build.sh config

# 6. build
./build.sh build
```

Output:
```
openwrt/bin/targets/ramips/mt7621/openwrt-*-xiaomi_mi-router-cr6608-squashfs-sysupgrade.bin
```

### After editing only `files/`

```bash
./build.sh overlay && ./build.sh repack
```
Repacks the image without recompiling everything — seconds instead of hours.

---

## What is NOT here — read this

**The mt7915 driver patch source.** This package was reconstructed from a *built*
image, so it ships the compiled module (`prebuilt/mt7915e.ko`) but not the `.patch`
that produced it. Without that patch the tree still builds, but `mt7915e` will not
expose `cr6608_rf_38dbm`, the debugfs snapshot will be missing, and the SKU request
ceiling stays at the stock value.

Your original build tree has it, most likely under:
```
package/kernel/mac80211/patches/
```
`driver-patch-NOTES.md` documents the parameter, the hook functions, the SKU values
in half-dBm, the debugfs interface and every trace line — enough to rewrite the patch
if the original is gone.

**Also not included** (the build steps generate them): the OpenWrt source itself, the
toolchain, and `.config`.

### Using the prebuilt module as a shortcut

If you rebuild against the *same* kernel (6.12.94) and only changed `files/`, you can
drop `prebuilt/mt7915e.ko` into your overlay at
`files/lib/modules/6.12.94/mt7915e.ko` to keep the 38 dBm behaviour without the
patch. This only works while the kernel version matches exactly — a different kernel
rejects the module (`vermagic` mismatch), and then the patch is the only route.

---

## Power chain in this build

`38 dBm` is asserted at every software layer:

1. `etc/config/wireless` — `txpower '38'` on both radios, `antenna_gain '0'`,
   `he_mu_beamformer` + `he_mu_beamformee` on both (full MU-MIMO)
2. `etc/modules.d/mt7915e` — `cr6608_rf_38dbm=1` enables the raised SKU ceiling
3. the driver patch — SKU ceiling + TXTRACE + debugfs snapshot
4. `usr/libexec/cr6608-txpower-lib` — upper bound and default both 38
5. `usr/sbin/cr6608-txpower-{collect,channel-table,step-test}` — evidence tools

The driver states its own scope:

> `38 dBm is a request only; EEPROM, regulatory, SAR, rate backoff and thermal limits
> retained; Factory remains read-only`

So the stack *requests* 38 dBm; the PA, regulatory domain, SAR and thermal limits
still bound what is actually radiated. `cr6608-eeprom-power` in this image is a
read-only inspector (`status`, `backup`) and never writes MTD.

Check the real numbers on a running unit:
```sh
logread | grep TXTRACE
cat /sys/kernel/debug/ieee80211/phy0/mt76/cr6608_txpower_state
cr6608-txpower-collect --out /tmp/evidence
```

---

## What changed in v22 (vs the stock RC image)

- **Firmware upload inside the Smart AP page** — Actions tab gains an upload card;
  goes through `cgi-io` to `/tmp/firmware.bin`, validated with `sysupgrade --test`
  before anything is written, then flashed (`-n` when keep-settings is off). New
  `flash_firmware` action in `dashctl`.
- **LuCI logout returns to the Smart AP page** (`action_logout` → `/`).
- **12 audited fixes** in `dashctl` / `dashapi2` / `dashboard.js` — the dead `nohup`
  port-restore timer, PID truncation in `kill_process`, `opkg`→`apk`, JSON control
  characters, firewall port truncation, the zone guard, MAC validation, SSID pipe
  shifting, `safe_host` option injection, radio distance truncation, load-average
  divisor, unused isolation note.
- **`he_mu_beamformee`** added to both radios (MU-MIMO was only half declared).
- Identity card shows customer name / phone / device explicitly.
