# CR6608 files/ overlay — Smart AP dashboard + owner settings

Drop the `files/` directory into the ROOT of your OpenWrt source tree
(same level as `package/`, `target/`), then rebuild:

    cp -a files /path/to/openwrt/
    make -j$(nproc)

Everything here is a plain rootfs overlay applied at image-build time.

## What it configures
- SSH (dropbear): port **2003**, root + password auth, listens on all interfaces.
- root / SSH / console password: **alihaker2003** (etc/shadow + 99-cr6608-root-pass).
- console login required (system.ttylogin=1).
- Dashboard login: **root / admin** (smartap.panel.password).
- Wi-Fi: txpower **38 dBm**, HE20 (2.4G) / HE80 (5G), full MU-MIMO / OFDMA /
  beamforming (see etc/config/wireless header).
- Firewall rule Allow-SSH-2003-WAN.

## Packages to select in menuconfig (dashboard dependencies)
    luci luci-theme-argon uhttpd uhttpd-mod-ubus rpcd
    iwinfo nftables firewall4 dnsmasq
    (kmod-mt7915e + mt7915 firmware are pulled by the target)

## Notes
- RF power = 38 dBm relies on your source-level mt7915 ceiling patch. This
  overlay does NOT write the Factory/EEPROM partition.
- etc/config/wireless uses country 'PA'; adjust if needed.
