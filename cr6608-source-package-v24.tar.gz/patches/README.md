# Driver patch — how to apply

`900-cr6608-lab-txpower-38dbm.patch` reproduces the 38 dBm behaviour of the shipped
`mt7915e.ko`. It is a **reconstruction** from binary analysis, not the original
author's file — read the header inside the patch before using it.

## Where it goes

OpenWrt builds mt76 from the `mt76` package. Patches live in:

```
openwrt/package/kernel/mt76/patches/
```

So:

```bash
mkdir -p openwrt/package/kernel/mt76/patches
cp patches/900-cr6608-lab-txpower-38dbm.patch openwrt/package/kernel/mt76/patches/
```

Then build normally. The patch applies to paths relative to the mt76 source root
(`mt7915/mcu.c`, `mt7915/init.c`, `mt7915/mt7915.h`).

## If it fails to apply

Function bodies around the hunks change between mt76 revisions, so a `.rej` is
likely on a tree far from the one this was written against. Fix it by hand:

```bash
cd openwrt
make package/kernel/mt76/{clean,prepare} V=s QUILT=1
cd build_dir/target-*/linux-*/mt76-*/
quilt push -a                 # stops at the failing patch
# edit the file(s) the patch touches, then:
quilt refresh
cp patches/900-cr6608-lab-txpower-38dbm.patch \
   ../../../../package/kernel/mt76/patches/
```

The three edits are small and independent — if only one hunk fails you can drop it
and keep the rest:

| hunk | file | what it does | required for 38 dBm? |
|---|---|---|---|
| 1 | `mt7915/mcu.c` | module parameter + SKU ceiling + trace | **yes** |
| 2 | `mt7915/init.c` | load-time banner | no (cosmetic) |
| 3 | `mt7915/mt7915.h` | accessor prototype | only if hunk 2 is kept |

Hunk 1 alone gives you the working 38 dBm request ceiling.

## Verify it worked

After building, the module must expose the parameter and the strings:

```bash
strings bin/targets/ramips/mt7621/*/mt7915e.ko | grep -E 'cr6608_rf_38dbm|CR6608-LAB-38'
```

Compare against the reference module in `../prebuilt/mt7915e.ko`:

```bash
strings ../prebuilt/mt7915e.ko | grep -cE 'cr6608_rf_38dbm'   # expect 2
```

On the running device:

```bash
cat /sys/module/mt7915e/parameters/cr6608_rf_38dbm    # expect Y
logread | grep CR6608
```

## Skipping the patch entirely

If you are rebuilding against the **same kernel (6.12.94)** and only changed
`files/`, you do not need the patch at all — copy the already-patched module into
the overlay:

```bash
mkdir -p files/lib/modules/6.12.94
cp prebuilt/mt7915e.ko files/lib/modules/6.12.94/
```

A different kernel version rejects it (`vermagic` mismatch); then the patch is the
only route.

## What the patch does not include

The original module also exposes a debugfs snapshot at
`/sys/kernel/debug/ieee80211/<phy>/mt76/cr6608_txpower_state`. That is pure
observability and is not reproduced here — it needs a struct member in `mt7915.h`
and a `debugfs_create_file` entry. `cr6608-txpower-collect` handles the file being
absent; it simply records fewer fields. `driver-patch-NOTES.md` lists the full field
set if you want to add it back.
