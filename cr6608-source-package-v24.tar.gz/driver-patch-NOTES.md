# mt7915 “CR6608-LAB-38” driver patch — reconstruction notes

**The patch source is not in this package.** It was reconstructed by analysing the
compiled `mt7915e.ko` shipped in the firmware. These notes describe precisely what
that module does, so the patch can be recreated if the original `.patch` is lost.

Applies to: `package/kernel/mac80211` (the mt76 driver), `mt7915/` sources.
Verified against kernel **6.12.94**, OpenWrt **25.12.5**.

---

## 1. Module parameter

Extracted from the built module:

```
parmtype=cr6608_rf_38dbm:bool
```

A `bool` module parameter `cr6608_rf_38dbm`, enabled at load time by
`files/etc/modules.d/mt7915e`:

```
mt7915e cr6608_rf_38dbm=1
```

Everything below must be gated behind this parameter so the stock code path is
completely unchanged when it is `0`.

## 2. Load-time banner

```
CR6608-LAB-38 observability enabled (38 dBm is a request only; EEPROM, regulatory,
SAR, rate backoff and thermal limits retained; Factory remains read-only)
```

This is the patch’s own statement of scope, and it is accurate: it raises the
**requested** SKU ceiling and adds tracing. It does not bypass regulatory limits,
does not touch SAR, does not disable thermal or rate backoff, and never writes the
Factory partition.

## 3. Custom symbols in the built module

```
cr6608_rf_38dbm                    # module parameter (bool)
cr6608_txpower_state               # per-phy snapshot struct + debugfs file name
mt7915_cr6608_txpower_state_copy   # snapshot copy helper
_cr6608_txpower_state_copy         # internal alias
```

## 4. Hook points

The patch touches the standard mt7915 power path. These are the stock functions
present in the module and the ones the patch instruments:

| function | role |
|---|---|
| `mt7915_init_txpower` | init-stage trace (`stage=mt7915-init`) |
| `mt7915_eeprom_get_target_power` | EEPROM ceiling read (`stage=mt7915-eeprom`) |
| `mt7915_eeprom_get_power_delta` | per-band delta read |
| `mt7915_mcu_set_txpower_sku` | **the SKU request ceiling is applied here** |
| `mt7915_mcu_set_txpower_frame` / `_frame_min` | path-SKU commands |
| `mt7915_update_txpower` | rate-stage trace (`stage=mt7915-rate`) |
| `mt7915_sku_group_len` | SKU group sizes (cck / ofdm / mcs / ru) |

## 5. SKU request ceiling

The 24.10 build of this patch stated the ceiling in one string:

```
SKU cck/ofdm=76 mcs=72 ru=68 half-dBm; request ceiling only, actual RF hardware/PA limited
```

Units are **half-dBm**:

| group | half-dBm | dBm |
|---|---|---|
| cck / ofdm | 76 | 38.0 |
| mcs | 72 | 36.0 |
| ru (HE resource units) | 68 | 34.0 |

Applied inside `mt7915_mcu_set_txpower_sku` when the parameter is on.

> `mcs` and `ru` are deliberately below 38. Raising them to 76 makes every group
> report 38.0 but changes nothing measurable — the PA saturates far below even the
> current 34–36 dBm ceiling, so those groups are not the binding constraint.

## 6. debugfs interface

The patch exposes a per-phy snapshot file:

```
/sys/kernel/debug/ieee80211/<phy>/mt76/cr6608_txpower_state
```

Read by `usr/sbin/cr6608-txpower-collect` (lines 367 and 372) before and after an
apply, to capture the full chain as evidence. Fields in the snapshot:

```
snapshot_seq snapshot_uptime_ms apply_uptime_ms valid inflight wiphy band channel
freq width chainmask chain0_raw_half_dbm chain1_raw_half_dbm eeprom_raw_max_half_dbm
band_power_delta_half_dbm chain0_half_dbm chain1_half_dbm eeprom_max_half_dbm
regulatory_raw_dbm driver_channel_max_dbm mac80211_dbm sar_half_dbm
path_delta_half_dbm bound_half_dbm rate_limit_half_dbm effective_half_dbm
sku path_sku mcu_rate_seq mcu_rate_attempted mcu_rate_ret
mcu_path_seq mcu_path_attempted mcu_path_ret
```

## 7. TXTRACE log lines

Three stages plus MCU results, all to the kernel log:

```
CR6608-TXTRACE stage=mt7915-init   band= channel= freq= chains= chain0_half_dbm= chain1_half_dbm=
                                   eeprom_max_half_dbm= delta_half_dbm= rate_max_half_dbm=
                                   path_delta_half_dbm= target_dbm= reg_dbm= max_dbm= sku= path_sku=

CR6608-TXTRACE stage=mt7915-eeprom band= channel= freq= chainmask= chain0_half_dbm= chain1_half_dbm=
                                   eeprom_max_half_dbm= rate_input_half_dbm= effective_half_dbm= sku=

CR6608-TXTRACE stage=mt7915-rate   band= channel= freq= width= mac80211_dbm= sar_half_dbm=
                                   path_delta_half_dbm= bound_half_dbm= rate_limit_half_dbm=
                                   effective_half_dbm= sku= path_sku=
                                   [sku_cck0= sku_ofdm0= sku_mcs0= sku_ru0=]
```

```
CR6608-LAB-38 band=%u MCU rate-SKU command completed
CR6608-LAB-38 band=%u MCU rate-SKU rejected: %d
CR6608-LAB-38 band=%u MCU path-SKU command completed
CR6608-LAB-38 band=%u MCU path-SKU rejected: %d
CR6608-LAB-38 band=%u path-SKU not configured
```

The “rejected” lines matter: if the MCU refuses the SKU command the requested
ceiling never reaches the firmware, and that shows up here and nowhere else.

## 8. Device-tree marker

```
mediatek,cr6608-lab-txpower-38dbm
```

An optional DT property the patch looks for, alongside the board compatible
`xiaomi,mi-router-cr6608`.

---

## Reading the chain on a live unit

```sh
logread | grep TXTRACE | tail -20
cat /sys/kernel/debug/ieee80211/phy0/mt76/cr6608_txpower_state
cr6608-txpower-collect --out /tmp/eviden
```

Follow the values left to right — **the smallest one wins**:

| field | limiter |
|---|---|
| `eeprom_max_half_dbm` | EEPROM / Factory calibration ceiling |
| `regulatory_raw_dbm` | regulatory domain |
| `sar_half_dbm` | SAR table |
| `rate_limit_half_dbm` | per-rate backoff |
| `bound_half_dbm` | final bound handed to the MCU |
| `effective_half_dbm` | what was actually programmed |

If `effective_half_dbm` is well below `target_dbm`, whichever stage matches
`effective` is the binding constraint — that is what to address, not the UCI
`txpower` value.

## Where the original patch lives

In your own build tree it will be under one of:

```
package/kernel/mac80211/patches/         # if patched against the mac80211 package
<your-feed>/mt76/patches/                # if you carry your own mt76 package
```

Copy that `.patch` into the new tree before building. Without it the tree still
builds, but `mt7915e` will not expose `cr6608_rf_38dbm`, the debugfs snapshot will
be absent, and the SKU ceiling stays at the stock value.
