#!/bin/bash
# CR6608 Smart AP — build helper.
#
#   ./build.sh deps             install Ubuntu build prerequisites
#   ./build.sh init             clone OpenWrt 25.12.5 + feeds into ./openwrt
#   ./build.sh patch            install the mt7915 38 dBm patch into the mt76 package
#   ./build.sh overlay          copy files/ into the build root
#   ./build.sh config           open menuconfig (pick MT7621 / CR6608 profile)
#   ./build.sh build            full build
#   ./build.sh verify           check the built module carries the patch
#   ./build.sh repack           repack the image only (after editing files/)
#   ./build.sh prebuilt-module  fallback: stage the already-patched mt7915e.ko
#
# First time:  deps → init → patch → overlay → config → build → verify
# After that:  overlay → repack   (seconds, no recompile)
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
OWRT="${OWRT:-$HERE/openwrt}"
TAG="${TAG:-v25.12.5}"

need_tree() {
  [ -d "$OWRT" ] || { echo "no OpenWrt tree at $OWRT — run: $0 init"; exit 1; }
}

case "${1:-}" in
deps)
  sudo apt update
  sudo apt install -y build-essential clang flex bison g++ gawk gcc-multilib \
    g++-multilib gettext git libncurses-dev libssl-dev python3-setuptools \
    rsync swig unzip zlib1g-dev file wget
  ;;

init)
  [ -d "$OWRT" ] || git clone https://git.openwrt.org/openwrt/openwrt.git "$OWRT"
  cd "$OWRT"
  git fetch --tags
  git checkout "$TAG"
  ./scripts/feeds update -a
  ./scripts/feeds install -a
  echo
  echo "OpenWrt $TAG ready at $OWRT"
  echo "If you have the mt7915 38 dBm patch, drop it into"
  echo "  $OWRT/package/kernel/mac80211/patches/  BEFORE building."
  echo "See driver-patch-NOTES.md."
  ;;

overlay)
  need_tree
  rm -rf "$OWRT/files"
  cp -a "$HERE/files" "$OWRT/files"
  echo "overlay installed: $(find "$OWRT/files" \( -type f -o -type l \) | wc -l) entries"
  ;;

patch)
  # Install the mt7915 38 dBm patch into the mt76 package.
  need_tree
  dst="$OWRT/package/kernel/mt76/patches"
  mkdir -p "$dst"
  cp -a "$HERE/patches/900-cr6608-lab-txpower-38dbm.patch" "$dst/"
  echo "patch installed: $dst/900-cr6608-lab-txpower-38dbm.patch"
  echo "It is a RECONSTRUCTION — if it fails to apply, see patches/README.md."
  ;;

prebuilt-module)
  # Fallback when the patch will not apply: reuse the already-patched module.
  # Only valid while the kernel version matches exactly (vermagic).
  need_tree
  kver="$(basename "$(ls -d "$OWRT"/build_dir/target-*/linux-*/linux-* 2>/dev/null | head -n1)" | sed 's/^linux-//')"
  [ -n "$kver" ] || kver=6.12.94
  mkdir -p "$HERE/files/lib/modules/$kver"
  cp -a "$HERE/prebuilt/mt7915e.ko" "$HERE/files/lib/modules/$kver/"
  echo "prebuilt mt7915e.ko staged at files/lib/modules/$kver/"
  echo "Reference module was built for 6.12.94; a different kernel will reject it."
  echo "Now run: $0 overlay && $0 repack"
  ;;

verify)
  # Confirm a freshly built module carries the patch.
  need_tree
  m="$(find "$OWRT/bin" "$OWRT/build_dir" -name 'mt7915e.ko' 2>/dev/null | head -n1)"
  [ -n "$m" ] || { echo "no built mt7915e.ko found — build first"; exit 1; }
  echo "checking $m"
  if strings "$m" | grep -q cr6608_rf_38dbm; then
    echo "  OK  cr6608_rf_38dbm present"
  else
    echo "  !!  cr6608_rf_38dbm MISSING — the patch did not apply"
  fi
  strings "$m" | grep -c 'CR6608-LAB-38' | sed 's/^/  CR6608-LAB-38 strings: /'
  ;;

config)
  need_tree
  cd "$OWRT"
  echo "Target System  : MediaTek Ralink MIPS"
  echo "Subtarget      : MT7621"
  echo "Target Profile : Xiaomi Mi Router CR6608"
  echo "Packages       : see packages-installed.txt"
  make menuconfig
  ;;

build)
  need_tree
  cd "$OWRT"
  make -j"$(nproc)"
  echo
  ls -la bin/targets/ramips/mt7621/*cr6608*sysupgrade.bin 2>/dev/null || \
    echo "no image found — rerun with: make -j1 V=s"
  ;;

repack)
  need_tree
  cd "$OWRT"
  make target/install -j"$(nproc)"
  ls -la bin/targets/ramips/mt7621/*cr6608*sysupgrade.bin 2>/dev/null || true
  ;;

*)
  sed -n '2,12p' "$0"
  exit 1
  ;;
esac
