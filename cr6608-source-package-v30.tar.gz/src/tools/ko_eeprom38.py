#!/usr/bin/env python3
"""Make mt7915e.ko report 38.0 dBm as the EEPROM target power.

WHY THIS EXISTS
---------------
The 26 dBm this board applies does not come from the regulatory database (that
now says 38.00 dBm) and it does not come from the UCI txpower setting (38 on
both radios). It comes from the EEPROM, through this call chain:

    __mt7915_init_txpower()
        target_power = max over chains of mt7915_eeprom_get_target_power(...)
        target_power += mt7915_eeprom_get_power_delta(...)
        target_power  = mt76_get_rate_power_limits(...)      # device-tree based
        target_power += mt76_tx_power_nss_delta(n_chains)
        target_power  = DIV_ROUND_UP(target_power, 2)
        chan->max_power = min(chan->max_reg_power, target_power)

`chan->max_power` is what mac80211 clamps the configured TX power to, and it is
the number iwinfo and LuCI display. With the EEPROM giving roughly 26 dBm, that
min() lands on 26 no matter how high the regulatory ceiling is.

WHAT THIS DOES
--------------
Replaces the first two instructions of mt7915_eeprom_get_target_power() with an
immediate return of 76, which is 38.0 dBm in the half-dBm units this function
uses:

    jr    $ra                 0x03E00008
    addiu $v0, $zero, 76      0x2402004C   (branch delay slot)

Eight bytes. No relocation lives inside them (the script checks), the file size
does not change, and every other structure in the ELF is untouched. The rest of
the function simply becomes unreachable.

The result is `chan->max_power = min(38 from the regulatory database, 47) = 38`.

WHAT IT DOES NOT DO
-------------------
It does not write the Factory/EEPROM flash partition - it edits the kernel
module in the firmware image, and the per-device RF calibration on the device is
never touched. It also does not change what the power amplifier can physically
emit; it removes the last software clamp so the whole stack asks for 38 dBm.

RECOVERY
--------
If a patched module misbehaves, flash any earlier image over the LAN cable. The
bootloader and the Factory partition are not involved.

USAGE
-----
    ko_eeprom38.py /path/to/mt7915e.ko          # patch in place
    ko_eeprom38.py /path/to/mt7915e.ko --check  # report only
"""
import struct, sys

SYMBOL = 'mt7915_eeprom_get_target_power'
TARGET_HALF_DBM = 76                     # 38.0 dBm
PATCH = struct.pack('<II', 0x03E00008,   # jr $ra
                    0x24020000 | TARGET_HALF_DBM)   # addiu $v0,$zero,76 (delay slot)


def sections(d):
    u32 = lambda o: struct.unpack('<I', d[o:o + 4])[0]
    u16 = lambda o: struct.unpack('<H', d[o:o + 2])[0]
    shoff, es, n, si = u32(0x20), u16(0x2e), u16(0x30), u16(0x32)
    raw = [dict(name=u32(shoff + i * es), off=u32(shoff + i * es + 16),
                size=u32(shoff + i * es + 20), idx=i) for i in range(n)]
    stroff = raw[si]['off']
    def nm(o):
        return d[stroff + o:d.index(b'\0', stroff + o)].decode()
    return {nm(s['name']): s for s in raw}


def main(path, check_only=False):
    d = bytearray(open(path, 'rb').read())
    if d[:4] != b'\x7fELF' or d[4] != 1:
        sys.exit('not a 32-bit ELF')
    secs = sections(d)
    text, sym, strt = secs['.text'], secs['.symtab'], secs['.strtab']
    u32 = lambda o: struct.unpack('<I', d[o:o + 4])[0]

    addr = size = None
    for i in range(sym['size'] // 16):
        o = sym['off'] + 16 * i
        nm_off = u32(o)
        name = d[strt['off'] + nm_off:d.index(b'\0', strt['off'] + nm_off)].decode()
        if name == SYMBOL:
            addr, size = u32(o + 4), u32(o + 8)
            break
    if addr is None:
        sys.exit(f'{SYMBOL} not found - wrong module?')

    rel = secs.get('.rel.text')
    clash = [r for r in range(rel['size'] // 8)
             if addr <= u32(rel['off'] + 8 * r) < addr + len(PATCH)] if rel else []
    if clash:
        sys.exit(f'refusing to patch: {len(clash)} relocation(s) inside the patch site')

    off = text['off'] + addr
    before = bytes(d[off:off + len(PATCH)])
    print(f'  {SYMBOL} @ {addr:#x} size {size:#x}, file offset {off:#x}')
    print(f'  relocations inside the patch site: 0')
    print(f'  before: {before.hex()}')
    print(f'  after : {PATCH.hex()}   (jr $ra / addiu $v0,$zero,{TARGET_HALF_DBM})')
    if before == PATCH:
        print('  already patched - nothing to do')
        return
    if check_only:
        print('  --check: not written')
        return
    d[off:off + len(PATCH)] = PATCH
    open(path, 'wb').write(d)
    print(f'  patched (size unchanged: {len(d)} bytes)')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    main(sys.argv[1], '--check' in sys.argv)
