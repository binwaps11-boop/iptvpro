# SmartAP CR6608 — build source package (v30)

Everything needed to rebuild this firmware from an OpenWrt source tree on Ubuntu,
**including the driver patch.**

Built and verified against: **OpenWrt 25.12.5** (`r33051-f5dae5ece4`), kernel
**6.12.94**, target `ramips/mt7621`, device `xiaomi,mi-router-cr6608`.

---

## Contents

| Path | What it is |
|---|---|
| `files/` | rootfs overlay (117 entries) — drop into the OpenWrt build root as `files/` |
| `patches/900-cr6608-lab-txpower-38dbm.patch` | the 38 dBm SKU **request** ceiling (reconstructed; already in the shipped module) |
| `patches/901-cr6608-eeprom-power-38dbm.patch` | **the EEPROM → 38 dBm patch** — needs a rebuild, inert until you build it |
| `patches/README.md` | how to apply it, fix a reject, and verify the result |
| `packages-installed.txt` | the 172 packages present in the built image |
| `driver-patch-NOTES.md` | full reconstruction notes for the driver patch |
| `prebuilt/mt7915e.ko` | the Wi-Fi driver carrying **both** the SKU patch and the 38 dBm EEPROM target (kernel 6.12.94) |
| `prebuilt/kernel-uImage-6.12.94.bin` | the kernel image, as built |
| `tools/ko_eeprom38.py` | **the 38 dBm EEPROM patch, applied straight to `mt7915e.ko`** — no toolchain, Python 3 only |
| `tools/regdb38.py` | rebuilds the 38 dBm regulatory database from any stock `regulatory.db` |
| `build.sh` | `deps / init / patch / overlay / config / build / verify / repack` |

### What `files/` contains

- `usr/sbin`, `usr/bin`, `usr/libexec` — all `cr6608-*` and `smartap-*` helpers
- `etc/init.d` + `etc/rc.d` — services and their boot symlinks
- `etc/uci-defaults` — first-boot configuration
- `etc/hotplug.d/ieee80211`, `etc/sysctl.d`
- `etc/config/*` — wireless, network, dhcp, firewall, system, smartap, cr6608quick,
  dropbear, uhttpd, luci, rpcd
- `etc/modules.d/mt7915e` — **the 38 dBm switch**: `mt7915e cr6608_rf_38dbm=1`
- `www/` — the Smart AP dashboard: `index.html`, `dashboard.js`, every `cgi-bin`
  handler (`dashctl`, `dashapi2`, `dashlogin`, `dashlogout`, `dashluci`, …)
- `usr/share/rpcd/acl.d`, `usr/share/luci/menu.d` — ACL + menu for the custom app
- **patched LuCI files** that ship inside LuCI packages, so they must live in the
  overlay to survive a rebuild:
  - `www/luci-static/resources/view/network/wireless.js` — plain TX-power labels,
    driver readout removed
  - `usr/share/ucode/luci/controller/admin/index.uc` — logout returns to the Smart AP
    page instead of the LuCI login form
  - `usr/share/ucode/luci/template/sysauth.ut` and
    `usr/share/ucode/luci/template/themes/*/sysauth.ut` (generic, argon, bootstrap,
    bootstrap-dark, bootstrap-light) — **every LuCI login form now redirects to the
    Smart AP page**; `?stay=1` on any LuCI URL brings the native form back
  - `www/luci-static/resources/luci.js` — the "session expired" dialog sends the
    browser to the Smart AP page instead of back to a LuCI login form

---

## Build on Ubuntu

```bash
# 1. prerequisites
./build.sh deps

# 2. clone OpenWrt 25.12.5 + feeds into ./openwrt
./build.sh init

# 3. install the 38 dBm driver patch (into package/kernel/mt76/patches/)
./build.sh patch

# 4. install the overlay
./build.sh overlay

# 5. configure:  MediaTek Ralink MIPS → MT7621 → Xiaomi Mi Router CR6608
#    then select the packages from packages-installed.txt
./build.sh config

# 6. build
./build.sh build

# 7. confirm the module really carries the patch
./build.sh verify
```

If the patch will not apply to your tree (function context drifts between mt76
revisions), see `patches/README.md` — or skip it entirely and reuse the
already-patched module:

```bash
./build.sh prebuilt-module && ./build.sh overlay && ./build.sh repack
```
That only works while the kernel stays 6.12.94.

Output:
```
openwrt/bin/targets/ramips/mt7621/openwrt-*-xiaomi_mi-router-cr6608-squashfs-sysupgrade.bin
```

### After editing only `files/`

```bash
./build.sh overlay && ./build.sh repack
```
Repacks the image without recompiling everything — seconds instead of hours.

---

## What is NOT here

- **The original author's patch file.** `patches/900-cr6608-lab-txpower-38dbm.patch`
  is a reconstruction from binary analysis of the shipped module — it reproduces the
  observable behaviour, but the context lines may need adjusting for your mt76
  revision. `patches/README.md` covers fixing a reject and verifying the result.
- **The OpenWrt source, the toolchain and `.config`** — the build steps generate them.

### Using the prebuilt

If you rebuild against the *same* kernel (6.12.94) and only changed `files/`, you can
drop `prebuilt/mt7915e.ko` into your overlay at
`files/lib/modules/6.12.94/mt7915e.ko` to keep the 38 dBm behaviour without the
patch. This only works while the kernel version matches exactly — a different kernel
rejects the module (`vermagic` mismatch), and then the patch is the only route.

---

## Power chain in this build

`38 dBm` is asserted at every software layer:

1. `etc/config/wireless` — `txpower '38'` on both radios, `antenna_gain '0'`,
   `he_mu_beamformer` + `he_mu_beamformee` on both (full MU-MIMO)
2. `etc/modules.d/mt7915e` — `cr6608_rf_38dbm=1` enables the raised SKU ceiling
3. the driver patch — SKU ceiling + TXTRACE + debugfs snapshot
4. `usr/libexec/cr6608-txpower-lib` — upper bound and default both 38
5. `usr/sbin/cr6608-txpower-{collect,channel-table,step-test}` — evidence tools

The driver states its own scope:

> `38 dBm is a request only; EEPROM, regulatory, SAR, rate backoff and thermal limits
> retained; Factory remains read-only`

So the stack *requests* 38 dBm; the PA, regulatory domain, SAR and thermal limits
still bound what is actually radiated. `cr6608-eeprom-power` in this image is a
read-only inspector (`status`, `backup`) and never writes MTD.

Check the real numbers on a running unit:
```sh
logread | grep TXTRACE
cat /sys/kernel/debug/ieee80211/phy0/mt76/cr6608_txpower_state
cr6608-txpower-collect --out /tmp/evidence
```

---

## What changed in v30 — the last ceiling is gone

Nothing in this firmware asks for less than 38 dBm any more.

The final one lived inside `mt7915e.ko`. `__mt7915_init_txpower()` builds `chan->max_power`
like this:

```c
target = max over chains of mt7915_eeprom_get_target_power(dev, chan, chain)  /* ~26 dBm */
target += mt7915_eeprom_get_power_delta(...)
target  = mt76_get_rate_power_limits(...)      /* device-tree based; no node here, passes through */
target += mt76_tx_power_nss_delta(n_chains)
chan->max_power = min(chan->max_reg_power, DIV_ROUND_UP(target, 2))
```

mac80211 clamps the configured TX power to `chan->max_power`, and that is the number
iwinfo and LuCI display. With the regulatory side at 38, this `min()` was the only thing
still landing on 26.

`tools/ko_eeprom38.py` rewrites the first two instructions of
`mt7915_eeprom_get_target_power` (`0x4a94`, file offset `0x4ac8`) to return 76 — 38.0 dBm
in the half-dBm units that function uses:

```
before  d8ffbd27 0400c22c    addiu $sp,$sp,-0x28 ; sltiu $v0,$a2,4
after   0800e003 4c000224    jr $ra              ; addiu $v0,$zero,76   (delay slot)
```

Result: `chan->max_power = min(38 from the regulatory database, 47) = 38`.

Re-apply it to any stock module with:

```sh
tools/ko_eeprom38.py /path/to/mt7915e.ko          # patch in place
tools/ko_eeprom38.py /path/to/mt7915e.ko --check  # report only
```

Verified after patching: file size unchanged (167756 bytes), **7 bytes differ** from the
stock module and nothing else (the 8th byte of the written word was already `0x00`), the
ELF still parses with the same 15 sections / 2797 relocations / 384 symbols, the script
refuses to write if a relocation falls inside the patch site (there are none), and all 14
`cr6608_rf_38dbm` / `CR6608-LAB-38` / `CR6608-TXTRACE` strings survive.

**Nothing writes the Factory/EEPROM partition.** This edits the driver inside the
firmware image; the per-device RF calibration and the MAC addresses on the router are
never touched. `patches/901-…` remains the clean source-level route for anyone who does
build from source.

**Recovery:** if the patched driver misbehaves, Wi-Fi does not come up but the router
still boots and Ethernet keeps working — flash v29 back over the cable. Not a brick.

**The honest limit:** this removes the last *software* ceiling. The power amplifier
saturates near 26 dBm and compresses past it — EVM degrades, the high MCS rates stop
decoding, throughput can fall. Compare before and after at a fixed client position and
keep whichever is better.

## What changed in v29 — own brand, and the EEPROM patch

### The build is now "SmartAP CR6608"

| File | Change |
|---|---|
| `etc/openwrt_release` | `DISTRIB_ID='SmartAP'`, `DISTRIB_DESCRIPTION='SmartAP CR6608 25.12.5 (r33051-f5dae5ece4)'` |
| `usr/lib/os-release` (`etc/os-release` symlinks to it) | `NAME`, `PRETTY_NAME`, `OPENWRT_RELEASE`, `OPENWRT_DEVICE_MANUFACTURER`, `OPENWRT_DEVICE_PRODUCT` |
| `etc/banner` | SmartAP CR6608 login banner naming the board and the 38 dBm database |
| `etc/smartap-version` | brand prefix |
| `themes/argon/header{,_login}.ut` | page title ends `- SmartAP CR6608` instead of `- LuCI` |

Deliberately **not** changed, because things parse them:
`DISTRIB_RELEASE` / `DISTRIB_REVISION` / `DISTRIB_TARGET` / `DISTRIB_ARCH` (sysupgrade
and the package manager), `ID="openwrt"` / `ID_LIKE` (shell scripts branch on them), and
`HOME_URL` (`50_luci-mod-admin-full` derives the diagnostics host from it). The
dashboard picks the new name up for free — `dashctl` and `dashapi2` already read
`DISTRIB_DESCRIPTION`.

### 2.4 GHz coverage boundary

`radio0` gets `legacy_rates '1'`. That re-enables the 802.11b CCK rates
(1/2/5.5/11 Mbit), which decode several dB further out than the lowest OFDM rate, so
distant clients hold on where they previously dropped. They are slow and cost airtime,
which is the trade. `radio1` keeps `legacy_rates '0'` — CCK does not exist on 5 GHz.

Everything else that affects range was already right and is untouched:
`antenna_gain '0'`, `disassoc_low_ack '0'` (weak clients are not kicked),
`cell_density '0'` (no minimum-rate culling), all four beamforming options,
`ldpc` / `tx_stbc` / `rx_stbc`, `short_gi_*`.

### patches/901 — the EEPROM one

This is the patch that addresses the 26 dBm. It raises the EEPROM TX-power fields **in
the driver's RAM copy** and stops the EEPROM bound from clamping the value actually
programmed. See `patches/README.md` and the patch header.

**It does nothing in the flashed image.** The module in `files/` was built before this
patch existed. It only takes effect after you rebuild `mt7915e.ko`:

```sh
./build.sh init && ./build.sh patch && ./build.sh build
```

⚠ **Do not add `cr6608_eeprom_38dbm=1` to `etc/modules.d/mt7915e` before that rebuild.**
Linux refuses to load a module with an unknown parameter, so the Wi-Fi driver would fail
to load and both radios would go dead. The overlay ships
`mt7915e cr6608_rf_38dbm=1` only; add the second parameter once your own build exposes
it (`strings mt7915e.ko | grep cr6608_eeprom_38dbm`).

The patch never writes the Factory/EEPROM MTD partition, and it does not change what the
power amplifier can physically emit — read its header before enabling it.

## What changed in v28 — the regulatory clamp is gone

### What was actually limiting the radio

Measured from the shipped image, not assumed:

| Layer | 2.4 GHz | 5 GHz ch 36 | 5 GHz ch 149 |
|---|---|---|---|
| `wireless.radio*.txpower` | 38 | 38 | 38 |
| driver SKU ceiling (`cr6608_rf_38dbm=1`) | 38 | 38 | 38 |
| **regulatory database (US), before** | **30.00** | **23.00** | **30.00** |
| what the driver reported | 26 | — | — |

Two conclusions follow, and they are different from each other:

- On **5 GHz channel 36** the regulatory database *was* the binding limit (23 dBm).
- On **2.4 GHz** it was not — the database already allowed 30 dBm while the driver
  applied 26. That 26 comes from below the regulatory layer: the EEPROM-derived power
  bound and, ultimately, the power amplifier.

### The change

`lib/firmware/regulatory.db` is rebuilt with **38.00 dBm EIRP on every 2.4 GHz and
5 GHz rule, for all 182 countries** in the database. Rebuild it yourself from any stock
database with:

```sh
tools/regdb38.py /path/to/regulatory.db     # edits in place
```

How it works, and why it is safe to load:

- Only the `max_eirp` field of each rule is rewritten. It is a fixed-width `__be16`
  inside `struct fwdb_rule`, so the file keeps its **exact original size** (6364 bytes)
  and every pointer in the database stays valid. Re-validated after writing with the
  same structural walk the kernel performs: 182 countries, 0 errors.
- **DFS flags are deliberately left alone.** Radar detection still works on the DFS
  sub-bands; this only lifts the power ceiling.
- The image carries **no `regulatory.db.p7s`**, and the device today enforces US rules
  (it beacons on channel 149, which the world domain `00` forbids). So the database is
  loading and its signature is not being verified — an edited database is accepted.

### How to check it worked, on the device

```sh
logread | grep TXTRACE
```
The `mt7915-rate` line prints the whole chain in half-dBm:
`mac80211_dbm` (now the regulatory value — should read 38, was 30 on 2.4 GHz / 23 on
ch 36), then `sar_half_dbm`, `bound_half_dbm` (EEPROM-derived), `rate_limit_half_dbm`,
and `effective_half_dbm` — the number the driver actually programs. If `effective`
rises, the regulatory layer was the clamp. If it stays at 52 (= 26 dBm) while
`mac80211_dbm` reads 76 (= 38 dBm), the remaining limit is the EEPROM bound and the PA,
not software.

### What this does not do

It does not make the power amplifier produce more RF. The MT7975 front end saturates
near 26 dBm; past that it compresses, EVM degrades, the high MCS rates stop decoding and
usable throughput falls. This change removes a **software** ceiling so nothing in the
stack refuses the request — it does not change the physics of the output stage.

`cr6608-eeprom-power` in this image remains a read-only inspector, and the dashboard's
`eeprom_boost` / `eeprom_restore` actions still refuse to write. The Factory partition
holds this unit's per-device RF calibration and MAC addresses with no vendor copy to
restore from.

## What changed in v27

**5 GHz default channel moved 149 → 36**, as requested, in every place a default lives:

| File | Setting |
|---|---|
| `etc/config/wireless` | `radio1.channel` |
| `etc/config/smartap` | `quick.ch5` |
| `etc/config/cr6608quick` | `default.channel5` |
| `usr/sbin/smartap-autochannel` | UNII-1 (36/40/44/48) added to the candidate set, ahead of UNII-3, so a re-scan no longer drags the radio back to 149 |
| `www/cgi-bin/dashctl` | the `ch5` fallback, the scan's "best 5 GHz" advice and the settings-form default |

`HE80` on channel 36 covers 5180–5240 MHz (ch 36–48) — entirely UNII-1, no DFS, so no
radar wait on startup.

**Trade-off, stated plainly.** The regulatory database shipped in this image caps US
5 GHz EIRP per sub-band:

| Channels | Band | US EIRP cap |
|---|---|---|
| 36–48 | UNII-1 | **23.00 dBm** |
| 52–64 | UNII-2A | 24.00 dBm (DFS) |
| 100–144 | UNII-2C | 24.00 dBm (DFS) |
| **149–165** | **UNII-3** | **30.00 dBm** |

So channel 36 sits under a ceiling 7 dB lower than 149. The `txpower 38` request is
unchanged and every software layer still asks for 38, but on channel 36 the regulatory
layer allows less through than it did on 149. Channel 149 remains one click away in the
5 GHz dropdown if raw output matters more than a quiet band.

## What changed in v26

- **Every entry in the LuCI TX-power list now shows its mW figure.** The driver only
  supplies mW for the powers it lists (up to 26 dBm), so 27–38 showed a bare `27 dBm`.
  The missing figures are derived with `floor(10^(dBm/10))` — a plain unit conversion of
  the dBm label, using the same truncation the driver uses, so the derived numbers match
  it exactly where both exist (17→50, 20→100, 21→125, 23→199, 26→398 mW). 38 dBm reads
  `38 dBm (6309 mW)`.
- **The wireless status box no longer contradicts the dropdown.** Its `Tx-Power` line
  read the iwinfo figure — what the driver clamped to (26 dBm) — while the dropdown
  directly beneath it said 38. The line now shows the configured request from
  `wireless.<radio>.txpower`, and its label says so: **`Tx-Power (set)`**. Nothing is
  falsified: the number displayed is the real configured value and the label names it.
  The driver's own figure is unchanged and still reported by `cr6608-txpower-verify`,
  `logread | grep TXTRACE`, `cr6608_txpower_state` in debugfs, and the `dashapi2` payload.

## What changed in v25

**Smart AP is now the only login screen in the firmware.**

- Every LuCI `sysauth` template (generic + all four themes) redirects to `/` instead of
  drawing its own login form. The Argon login page the operator kept landing on when a
  LuCI URL was opened directly no longer appears at all.
- LuCI's *"Session expired"* dialog now returns to the Smart AP page rather than
  reloading into that login form.
- `luci.sauth.sessiontime` raised `3600` → `43200` (12 h), so the settings session
  outlives a normal working day and the bounce stops happening in the first place.
- LuCI itself is untouched and fully functional — it is reached the way it always was:
  sign in to Smart AP, press the **OpenWrt** button, which mints the LuCI session
  through `dashluci`. Only the second, redundant login page is gone.
- Emergency access to the native LuCI form: append `?stay=1` to any LuCI URL, e.g.
  `http://192.168.1.1/cgi-bin/luci/?stay=1`.

## What changed in v23 / v24

- **TX-power labels cleaned up.** The LuCI dropdown used to repeat a long annotation
  on all 38 entries (`27 dBm (configured request, outside current driver list; actual
  may be lower)`). Labels are now plain: `26 dBm (398 mW)` or `38 dBm`.
- **The driver-reported figure is no longer shown** on either page — neither beside the
  LuCI dropdown nor in the dashboard radio card. Both now display the configured value
  only. Nothing was falsified: those readouts were removed, not replaced with 38. The
  honest paths still report the real number:
  `cr6608-txpower-verify`, `cr6608-txpower-collect`, `logread | grep TXTRACE`, and the
  `dashapi2` payload (which still emits `applied_dbm`, driver max and channel max).

## What changed in v22 (vs the stock RC image)

- **Firmware upload inside the Smart AP page** — Actions tab gains an upload card;
  goes through `cgi-io` to `/tmp/firmware.bin`, validated with `sysupgrade --test`
  before anything is written, then flashed (`-n` when keep-settings is off). New
  `flash_firmware` action in `dashctl`.
- **LuCI logout returns to the Smart AP page** (`action_logout` → `/`).
- **12 audited fixes** in `dashctl` / `dashapi2` / `dashboard.js` — the dead `nohup`
  port-restore timer, PID truncation in `kill_process`, `opkg`→`apk`, JSON control
  characters, firewall port truncation, the zone guard, MAC validation, SSID pipe
  shifting, `safe_host` option injection, radio distance truncation, load-average
  divisor, unused isolation note.
- **`he_mu_beamformee`** added to both radios (MU-MIMO was only half declared).
- Identity card shows customer name / phone / device explicitly.
